Periodic table of HTML 5 elements
=================================

There have been a few different versions of this and it is not my original idea. This version is made with css only, so modern browsers please.

<a href="http://madebymike.com.au/html5-periodic-table">http://madebymike.com.au/html5-periodic-table</a>
