Small project to display bar chart on a web page from a csv file.
